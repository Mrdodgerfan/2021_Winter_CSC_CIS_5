/*
 * File:   main.cpp
 * Author: Francisco Rodriguez
 * Assignment: Project #2 Version 1
 * Description: How Many Can You Answer Competitive Version
 * Created on February 12, 2021, 4:20 PM
 */
#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;
// EndGameStatDisplayer is an example of overloading functions
void endGameStatDisplayer(int, int, string[]);
void endGameStatDisplayer(int[][2], int[]);
int answerCorrectorPlayer1(const int[], int[][2]);
int answerCorrectorPlayer2(const int[], int[][2]);
int pointMeterPlayer1(int);
int healthMeterPlayer2(int);
// demonstrates passing data by value by only changing the value within the scope of the function
void nextPossibleScorePlayer1(int);
void nextPossibleScorePlayer2(int);
//rulesDisplay function
void rulesDisplay(int one = 1, int two = 2, int three = 3);
//shows Searching and Storing arrays
int findingFifteen(const int[], int, int);
const int sizeCorrectAnswers = 5;
int main(int argc, char** argv) {
    const int SIZE = 11;
    int userInput[5][2];
    int randTopNum[SIZE] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10},
            randBotNum[SIZE] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10},
            answerAdd[5];
    string arrName[2];
    int plr1wng, plr2wng, pntsPlr1, pntsPlr2;
    int correctAnswers[sizeCorrectAnswers] = {9, 5, 9, 15, 6};
    int similarAnswers;
    char restart;//Choice to restart
    do{
        //Rules Display
        rulesDisplay();
        //answers for the math problems
        answerAdd[0] = randTopNum[0] + randBotNum[9];
        answerAdd[1] = randTopNum[2] + randBotNum[3];
        answerAdd[2] = randTopNum[4] + randBotNum[5];
        answerAdd[3] = randTopNum[8] + randBotNum[7];
        answerAdd[4] = randTopNum[5] + randBotNum[1];
        for (int user = 0; user <= 1; user++){
            cout<<"Enter username for player # "<<(user + 1)<<": ";
            cin>>arrName[user];
        }
        
    return 0;
}
