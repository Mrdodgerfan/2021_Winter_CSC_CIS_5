/*
 * File:   main.cpp
 * Author: Francisco Rodriguez
 * Assignment: Project #2 Version 2
 * Description: How Many Can You Answer Competitive Version
 * Created on February 13, 2021, 4:20 PM
 */
#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;
// EndGameStatDisplayer is an example of overloading functions
void endGameStatDisplayer(int, int, string[]);
void endGameStatDisplayer(int[][2], int[]);
int answerCorrectorPlayer1(const int[], int[][2]);
int answerCorrectorPlayer2(const int[], int[][2]);
int pointMeterPlayer1(int);
int healthMeterPlayer2(int);
// demonstrates passing data by value by only changing the value within the scope of the function
void nextPossibleScorePlayer1(int);
void nextPossibleScorePlayer2(int);
//rulesDisplay function
void rulesDisplay(int one = 1, int two = 2, int three = 3);
//shows Searching and Storing arrays
int findingFifteen(const int[], int, int);
const int sizeCorrectAnswers = 5;
int main(int argc, char** argv) {
    const int SIZE = 11;
    int userInput[5][2];
    int randTopNum[SIZE] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10},
            randBotNum[SIZE] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10},
            answerAdd[5];
    string arrName[2];
    int plr1wng, plr2wng, pntsPlr1, pntsPlr2;
    int correctAnswers[sizeCorrectAnswers] = {9, 5, 9, 15, 6};
    int similarAnswers;
    char restart;//Choice to restart
    do{
        //Rules Display
        rulesDisplay();
        //answers for the math problems
        answerAdd[0] = randTopNum[0] + randBotNum[9];
        answerAdd[1] = randTopNum[2] + randBotNum[3];
        answerAdd[2] = randTopNum[4] + randBotNum[5];
        answerAdd[3] = randTopNum[8] + randBotNum[7];
        answerAdd[4] = randTopNum[5] + randBotNum[1];
        for (int user = 0; user <= 1; user++){
            cout<<"Enter username for player # "<<(user + 1)<<": ";
            cin>>arrName[user];
        }
        for (int player = 0; player <= 1; player++){
            if (player == 0){
                cout<<"Player: "<<arrName[player]<<endl;
                for (int x = 0; x <= 4; x++){
                    //Displays the math problem
                    if (x == 0){
                        plr1wng = answerCorrectorPlayer1(answerAdd,userInput);
                        pntsPlr1= pointMeterPlayer1(plr1wng);
                        cout<<randTopNum[0]<<" + "<<randBotNum[9]<<" = ";
                        cin>>userInput[0][0];
                        //Damage and Health System
                        plr1wng = answerCorrectorPlayer1(answerAdd,userInput);
                        pntsPlr1 = pointMeterPlayer1(plr1wng);
                        //Display for points
                        cout<<"                                           "<<
                            "Player 1's Points: "<<(pntsPlr1 + 50)<<endl;
                        //Displays the next possible score
                        nextPossibleScorePlayer1(pntsPlr1);
                    }
                    else if (x == 1){
                        cout<<randTopNum[2]<<" + "<<randBotNum[3]<<" = ";
                        cin>>userInput[1][0];
                        //Damage and Health System
                        plr1wng = answerCorrectorPlayer1(answerAdd,userInput);
                        pntsPlr1 = pointMeterPlayer1(plr1wng);
                        //Display for points
                        cout<<"                                           "<<
                            "Player 1's Points: "<<(pntsPlr1 + 50)<<endl;
                        //Displays the next possible score
                        nextPossibleScorePlayer1(pntsPlr1);
                    }
                    else if (x == 2){
                        cout<<randTopNum[4]<<" + "<<randBotNum[5]<<" = ";
                        cin>>userInput[2][0];
                        //Damage and Health System
                        plr1wng = answerCorrectorPlayer1(answerAdd,userInput);
                        pntsPlr1 = pointMeterPlayer1(plr1wng);
                        //Display for Health
                        cout<<"                                           "<<
                            "Player 1's Points: "<<(pntsPlr1 + 50)<<endl;
                        //Displays the next possible score
                        nextPossibleScorePlayer1(pntsPlr1);
                    }
                    else if (x == 3){
                        cout<<randTopNum[8]<<" + "<<randBotNum[7]<<" = ";
                        cin>>userInput[3][0];
                        //Damage and Health System
                        plr1wng = answerCorrectorPlayer1(answerAdd,
                                                                   userInput);
                        pntsPlr1 = pointMeterPlayer1(plr1wng);
                        //Display for points
                        cout<<"                                           "<<
                            "Player 1's Points: "<<(pntsPlr1 + 50)<<endl;
                        //Displays the next possible score
                        nextPossibleScorePlayer1(pntsPlr1);
                    }
                    else if (x == 4){
                        cout<<randTopNum[5]<<" + "<<randBotNum[1]<<" = ";
                        cin>>userInput[4][0];
                        //Damage and Health System
                        plr1wng = answerCorrectorPlayer1(answerAdd,
                                                                   userInput);
                        pntsPlr1 = pointMeterPlayer1(plr1wng);
                        //Display for points
                        cout<<"                                           "<<
                            "Player 1's Points: "<<(pntsPlr1 + 50)<<endl;
                        //Displays the next possible score
                        nextPossibleScorePlayer1(pntsPlr1);
                    }
                }
            }
            if (player == 1){
                cout<<"Player: "<<arrName[player]<<endl;
                //Displays the math problem
                cout<<randTopNum[0]<<" + "<<randBotNum[9]<<" = ";
                cin>>userInput[0][1];

                plr2wng = answerCorrectorPlayer2(answerAdd, userInput);
                pntsPlr2 = healthMeterPlayer2(plr2wng);
                //Display for Health
                cout<<"                                           "<<
                    "Player 2's Points: "<<(pntsPlr2 + 50)<<endl;
                nextPossibleScorePlayer2(pntsPlr2);
                cout<<randTopNum[2]<<" + "<<randBotNum[3]<<" = ";
                cin>>userInput[1][1];
                plr2wng = answerCorrectorPlayer2(answerAdd, userInput);
                pntsPlr2 = healthMeterPlayer2(plr2wng);
                //Display for Health
                cout<<"                                           "<<
                    "Player 2's Points: "<<(pntsPlr2 + 50)<<endl;
                nextPossibleScorePlayer2(pntsPlr2);
                cout<<randTopNum[4]<<" + "<<randBotNum[5]<<" = ";
                cin>>userInput[2][1];
                plr2wng = answerCorrectorPlayer2(answerAdd, userInput);
                pntsPlr2 = healthMeterPlayer2(plr2wng);
                //Display for Health
                cout<<"                                           "<<
                    "Player 2's Points: "<<(pntsPlr2 + 50)<<endl;
                nextPossibleScorePlayer2(pntsPlr2);
                cout<<randTopNum[8]<<" + "<<randBotNum[7]<<" = ";
                cin>>userInput[3][1];
                plr2wng = answerCorrectorPlayer2(answerAdd, userInput);
                pntsPlr2 = healthMeterPlayer2(plr2wng);
                //Display for Health
                cout<<"                                           "<<
                    "Player 2's Points: "<<(pntsPlr2 + 50)<<endl;
                nextPossibleScorePlayer2(pntsPlr2);
                cout<<randTopNum[5]<<" + "<<randBotNum[1]<<" = ";
                cin>>userInput[4][1];
                plr2wng = answerCorrectorPlayer2(answerAdd, userInput);
                pntsPlr2 = healthMeterPlayer2(plr2wng);
                //Display for Health
                cout<<"                                           "<<
                    "Player 2's Points: "<<(pntsPlr2 + 50)<<endl;
                nextPossibleScorePlayer2(pntsPlr2);
            }
        }
        //Both EndGameStatDisplayers is an example of
        //Displays the the players' stats when the game ends
        endGameStatDisplayer(pntsPlr1, pntsPlr2, arrName);
        cout<<"                    Player's Stats\n";
        cout<<"Player 1: "<<arrName[0]<<", Player 2: "<<arrName[1]<<endl;
        cout<<"========================================================\n";
        cout<<"Player 1 Answers |  Correct Answers  |  Player 2 Answers"
            <<endl;
        endGameStatDisplayer(userInput, answerAdd);
        cout<<arrName[0]<<" has wrong answers: "
            <<answerCorrectorPlayer1(answerAdd, userInput)<<"/5\n";
        cout<<arrName[1]<<" has wrong answers: "
            <<answerCorrectorPlayer2(answerAdd, userInput)<<"/5\n";
        //This is also an example of an argument list
        //linear searches which problem has 15 for its correct answer.
        similarAnswers = findingFifteen(correctAnswers, sizeCorrectAnswers,
                                        15);
        if (similarAnswers == -1){
            cout<<"Sorry there are no problems that has 15 as a correct"<<
                " answer\n";
        }
        else{
            cout<<"15 is the correct answer for problem: "
                <<(similarAnswers + 1)<<endl;
        }
        cout<<"Would you like this program to restart itself? (Y/N): ";
        cin>>restart;
    }while(restart == 'Y' || restart == 'y');
    return 0;
}
